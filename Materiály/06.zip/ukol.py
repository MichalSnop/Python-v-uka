pismena = ["a", "a", "b", "c", "d", "a", "e", "g", "m", "e"]

# 1) zeptat se uzivatele   -->   input()
# 2) smazat pismenko       -->   .remove()
# ... (pokracovat)     ------>   while

# 1, 2, 3, 4   --->  True 
# 0            ---> False

# [1, 2]       ---> True 
# [0]          ---> True
# []           ---> False

while pismena:
    input_user = input("ktere pismeno chces vyhodit?")
    # SPATNE: input(input_user)
    while input_user in pismena:
        pismena.remove(input_user)
    print(pismena)