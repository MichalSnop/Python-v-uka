import muj_modul
print(
    f"Jmeno: {muj_modul.udaje_uzivatele['jmeno']}",
    f"email: {muj_modul.udaje_uzivatele['email']}",
    sep="\n"
)
