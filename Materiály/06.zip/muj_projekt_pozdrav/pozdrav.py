from muj_balicek.jmena import uzivatelska_jmena

for jmeno in uzivatelska_jmena:
    print(f"Ahoj, {jmeno}")